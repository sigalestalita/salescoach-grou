// Sales Coach - Content Script
// Floating overlay with: recording controls, live transcription, real-time coaching tips.

(() => {
  if (document.getElementById('salescoach-overlay')) {
    // Já existe overlay nesta aba. Pedir gravação de novo não pode abrir uma
    // segunda: duas gravações ao mesmo tempo misturavam os pedaços das duas
    // num arquivo só, que nascia sem cabeçalho e o serviço de transcrição
    // recusava. Se já estiver gravando, não faz nada.
    window.__salescoachStartRecording?.();
    return;
  }

  const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InhncGZ1dW5tbWprZ3dqZWZvZmNkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzU0ODQwOTIsImV4cCI6MjA5MTA2MDA5Mn0.GhNqsTHRY59h4D13rYeLbwgaq6-x0nqJzfv9dXWcUAQ';
  const SUPABASE_URL = 'https://xgpfuunmmjkgwjefofcd.supabase.co';
  const SUPABASE_REALTIME_WS = 'wss://xgpfuunmmjkgwjefofcd.supabase.co/realtime/v1/websocket';

  let mediaRecorder = null;
  let recordedChunks = [];  // pedaços da gravação em curso
  let screenStream = null;
  let micStream = null;
  let audioContext = null;
  // Voz do cliente: chamada (remote-audio.js) ou aba compartilhada, a que tiver som.
  let clienteMix = null;
  // Trilhas do live: { vendedor, cliente } → { ws, ctx, source, processor, ... }
  let liveChannels = {};
  let liveStartedAt = 0;
  let liveStopping = false;
  let tipsWS = null;
  let tipsHeartbeatInterval = null;
  let realtimeRef = 1;
  let timerInterval = null;
  let startTime = null;
  let meetingId = null;
  // Pedido de gravação em andamento (seletor de tela aberto). O popup injeta
  // este script, que já começa a gravar, e logo depois manda "startRecording":
  // sem esta trava, eram dois seletores de tela e duas gravações disputando o
  // mesmo estado, e a segunda atropelava a primeira.
  let starting = false;
  // Token capturado no início, para o envio não depender de chrome.storage
  // caso a extensão seja recarregada no meio da reunião.
  let lastToken = null;
  // Gravação principal subindo: fechar a aba agora perderia o vídeo.
  let uploading = false;
  // Microfone na mistura da gravação (para trocar sem parar a gravação).
  let mixDest = null;
  let micSource = null;
  // Só o coach ao vivo: o robô de reunião grava esta chamada, a extensão só ouve.
  let soCoach = false;
  let coachAtivo = false;

  // ── Overlay DOM ──
  //
  // Painel claro: a dica mais recente em destaque, o tempo de gravação e o
  // botão de parar no cabeçalho, medidores de áudio e a transcrição recolhida.
  // Arrastável pelo cabeçalho; minimizado vira uma pílula com o tempo.
  const overlay = document.createElement('div');
  overlay.id = 'salescoach-overlay';
  overlay.innerHTML = `
    <div class="sc-head" id="sc-head" title="Arraste para mover">
      <span class="sc-grip" aria-hidden="true"><i></i><i></i><i></i><i></i><i></i><i></i></span>
      <img class="sc-mark" src="${chrome.runtime.getURL('icon48.png')}" alt="">
      <span class="sc-name">Sales Coach</span>
      <span class="sc-spacer"></span>
      <span class="sc-rec" id="sc-rec" hidden><i></i><span>REC <span id="sc-timer">00:00</span></span></span>
      <button type="button" class="sc-ibtn sc-stop" id="sc-btn-stop" title="Parar e enviar" aria-label="Parar e enviar" hidden><span></span></button>
      <button type="button" class="sc-ibtn" id="sc-minimize" title="Minimizar" aria-label="Minimizar">
        <svg viewBox="0 0 14 14" fill="none"><path d="M3 7h8" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>
      </button>
    </div>
    <div class="sc-body">
      <div id="sc-init" class="sc-status sending">Iniciando a gravação…</div>
      <div id="sc-recording" class="sc-section" hidden>
        <div class="sc-confirm" id="sc-confirm" hidden>
          <b>Encerrar a gravação?</b>
          <span id="sc-confirm-text">A gravação é enviada para análise. O resultado chega em alguns minutos.</span>
          <div class="sc-row">
            <button type="button" class="sc-btn" id="sc-confirm-no">Continuar gravando</button>
            <button type="button" class="sc-btn sc-btn-danger" id="sc-confirm-yes">Parar e enviar</button>
          </div>
        </div>
        <div id="sc-alerts" class="sc-section" hidden></div>
        <div id="sc-tips"><div class="sc-empty">Conectando o coach…</div></div>
        <div class="sc-nav" id="sc-nav" hidden>
          <button type="button" class="sc-ibtn" id="sc-prev" title="Dica anterior" aria-label="Dica anterior">‹</button>
          <span class="sc-nav-pos" id="sc-nav-pos"></span>
          <button type="button" class="sc-ibtn" id="sc-next" title="Próxima dica" aria-label="Próxima dica">›</button>
          <span class="sc-spacer"></span>
          <button type="button" class="sc-nova" id="sc-nova" hidden></button>
        </div>
        <div class="sc-roteiro" id="sc-roteiro" hidden>
          <div class="sc-rot-head">
            <span class="sc-label" id="sc-rot-title">Roteiro</span>
            <span class="sc-rot-count" id="sc-rot-count"></span>
            <span class="sc-spacer"></span>
            <button type="button" class="sc-link" id="sc-rot-toggle" aria-expanded="true">recolher</button>
          </div>
          <div class="sc-rot-bar"><i id="sc-rot-bar"></i></div>
          <ol class="sc-rot-list" id="sc-rot-list"></ol>
          <label class="sc-rot-trocar" id="sc-rot-trocar-wrap" hidden>Trocar roteiro
            <select id="sc-rot-trocar"></select>
          </label>
        </div>
        <div class="sc-meters" aria-label="Nível de áudio">
          <span>Você</span><div class="sc-bar"><i id="sc-meter-vendedor"></i></div>
          <span>Cliente</span><div class="sc-bar"><i id="sc-meter-cliente"></i></div>
        </div>
        <div class="sc-tx">
          <div class="sc-tx-head">
            <span class="sc-label">Transcrição</span>
            <button type="button" class="sc-link" id="sc-tx-btn" aria-expanded="false">ver tudo</button>
          </div>
          <div class="sc-tx-last" id="sc-live-text">…</div>
          <div class="sc-tx-full" id="sc-tx-full" hidden></div>
        </div>
      </div>
      <div id="sc-status-msg" hidden></div>
    </div>
    <button type="button" class="sc-pill" id="sc-pill" title="Abrir o painel">
      <span class="sc-pill-dot"></span>
      <span class="sc-pill-time" id="sc-pill-time">00:00</span>
      <span class="sc-pill-new" id="sc-pill-new" hidden></span>
    </button>
  `;
  document.body.appendChild(overlay);

  const $id = (id) => document.getElementById(id);
  const initEl = $id('sc-init');
  const recordingEl = $id('sc-recording');
  const statusMsgEl = $id('sc-status-msg');
  const timerEl = $id('sc-timer');
  const recEl = $id('sc-rec');
  const stopBtn = $id('sc-btn-stop');
  const minimizeBtn = $id('sc-minimize');
  const confirmEl = $id('sc-confirm');
  const alertsEl = $id('sc-alerts');
  const tipsEl = $id('sc-tips');
  const navEl = $id('sc-nav');
  const navPos = $id('sc-nav-pos');
  const prevBtn = $id('sc-prev');
  const nextBtn = $id('sc-next');
  const novaBtn = $id('sc-nova');
  const rotEl = $id('sc-roteiro');
  const rotList = $id('sc-rot-list');
  const rotCount = $id('sc-rot-count');
  const rotBar = $id('sc-rot-bar');
  const rotToggle = $id('sc-rot-toggle');
  const rotTitle = $id('sc-rot-title');
  const rotTrocarWrap = $id('sc-rot-trocar-wrap');
  const rotTrocar = $id('sc-rot-trocar');
  const liveTextEl = $id('sc-live-text');
  const txFullEl = $id('sc-tx-full');
  const txBtn = $id('sc-tx-btn');
  const pillBtn = $id('sc-pill');
  const pillTime = $id('sc-pill-time');
  const pillNew = $id('sc-pill-new');
  const meterEls = { vendedor: $id('sc-meter-vendedor'), cliente: $id('sc-meter-cliente') };

  // Minimizar / restaurar. Dicas que chegam minimizado viram contador na pílula.
  let unseenTips = 0;
  function setMinimized(min) {
    overlay.classList.toggle('minimized', min);
    if (!min) { unseenTips = 0; updatePill(); }
  }
  function updatePill() {
    pillNew.hidden = unseenTips === 0;
    pillNew.textContent = unseenTips === 1 ? '1 dica nova' : `${unseenTips} dicas novas`;
  }
  minimizeBtn.addEventListener('click', (e) => { e.stopPropagation(); setMinimized(true); });
  pillBtn.addEventListener('click', () => setMinimized(false));

  // Parar pede confirmação: o botão fica no cabeçalho, perto do minimizar.
  stopBtn.addEventListener('click', () => {
    setMinimized(false);
    $id('sc-confirm-text').textContent = coachAtivo
      ? 'As dicas ao vivo param. O robô continua gravando até a reunião acabar.'
      : `A gravação de ${timerEl.textContent} é enviada para análise. O resultado chega em alguns minutos.`;
    $id('sc-confirm-yes').textContent = coachAtivo ? 'Encerrar as dicas' : 'Parar e enviar';
    $id('sc-confirm-no').textContent = coachAtivo ? 'Continuar' : 'Continuar gravando';
    confirmEl.hidden = false;
    $id('sc-confirm-no').focus();
  });
  $id('sc-confirm-no').addEventListener('click', () => { confirmEl.hidden = true; });
  $id('sc-confirm-yes').addEventListener('click', () => { confirmEl.hidden = true; stopRecording(); });

  prevBtn.addEventListener('click', () => verDica(tipIdx - 1));
  nextBtn.addEventListener('click', () => verDica(tipIdx + 1));
  novaBtn.addEventListener('click', () => verDica(tips.length - 1));
  rotToggle.addEventListener('click', () => {
    const open = rotList.hidden;
    rotList.hidden = !open;
    rotTrocarWrap.hidden = !open || rotTrocar.options.length < 2;
    rotToggle.setAttribute('aria-expanded', String(open));
    rotToggle.textContent = open ? 'recolher' : 'ver perguntas';
  });
  rotList.addEventListener('click', (e) => {
    const li = e.target.closest('li[data-i]');
    if (!li) return;
    const i = +li.dataset.i;
    roteiro.feitas[i] = roteiro.feitas[i] ? 0 : 1;
    renderRoteiro();
  });
  rotTrocar.addEventListener('change', () => usarRoteiro(rotTrocar.value));
  txBtn.addEventListener('click', () => {
    const open = txFullEl.hidden;
    txFullEl.hidden = !open;
    liveTextEl.hidden = open;
    txBtn.setAttribute('aria-expanded', String(open));
    txBtn.textContent = open ? 'recolher' : 'ver tudo';
    if (open) txFullEl.scrollTop = txFullEl.scrollHeight;
  });

  // ── Arrastar ──
  // A posição fica salva: a próxima reunião abre o painel no mesmo lugar.
  function placeAt(left, top) {
    const r = overlay.getBoundingClientRect();
    const x = Math.min(Math.max(8, left), Math.max(8, window.innerWidth - r.width - 8));
    const y = Math.min(Math.max(8, top), Math.max(8, window.innerHeight - 48));
    overlay.style.left = `${x}px`;
    overlay.style.top = `${y}px`;
    overlay.style.right = 'auto';
    return { left: x, top: y };
  }
  $id('sc-head').addEventListener('pointerdown', (e) => {
    if (e.button !== 0 || e.target.closest('button')) return;
    const r = overlay.getBoundingClientRect();
    const dx = e.clientX - r.left, dy = e.clientY - r.top;
    overlay.classList.add('dragging');
    const move = (ev) => placeAt(ev.clientX - dx, ev.clientY - dy);
    const up = (ev) => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
      overlay.classList.remove('dragging');
      safeStorageSet({ overlayPos: placeAt(ev.clientX - dx, ev.clientY - dy) });
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
    e.preventDefault();
  });
  try {
    chrome.storage.local.get(['overlayPos']).then(({ overlayPos }) => {
      if (overlayPos && Number.isFinite(overlayPos.left)) placeAt(overlayPos.left, overlayPos.top);
    }).catch(() => {});
  } catch {}
  window.addEventListener('resize', () => {
    if (overlay.style.right === 'auto') placeAt(parseFloat(overlay.style.left), parseFloat(overlay.style.top));
  });

  // ── Avisos em linguagem simples ──
  // Cada aviso tem uma chave; o mesmo problema não aparece duas vezes.
  const alerts = new Map();
  function setAlert(key, alert) {
    if (alert) alerts.set(key, alert); else alerts.delete(key);
    alertsEl.innerHTML = '';
    alertsEl.hidden = alerts.size === 0;
    for (const a of alerts.values()) {
      const el = document.createElement('div');
      el.className = `sc-alert ${a.kind}`;
      el.setAttribute('role', 'status');
      const icon = a.kind === 'info' ? '<span class="sc-spin"></span>' : '!';
      // O motivo fica escrito no aviso: só no title (passar o mouse), ninguém
      // achava no meio da reunião.
      const motivo = a.detail ? `<small class="sc-alert-detail">Motivo: ${escape(a.detail)}</small>` : '';
      el.innerHTML = `<span class="sc-alert-ic">${icon}</span><div><b>${escape(a.title)}</b><span>${escape(a.text)}</span>${motivo}</div>`;
      if (a.detail) el.title = a.detail;
      if (a.action) {
        const b = document.createElement('button');
        b.type = 'button';
        b.className = 'sc-btn sc-btn-primary sc-alert-btn';
        b.textContent = a.action.label;
        b.addEventListener('click', a.action.onClick);
        el.querySelector('div').appendChild(b);
      }
      alertsEl.appendChild(el);
    }
  }
  const RECONNECTING = {
    kind: 'info', title: 'Dicas pausadas, reconectando…', text: 'A gravação continua normalmente. Nada se perde.',
  };

  // O painel some no fim de cada gravação, mas este script continua vivo na
  // aba. Se a pessoa grava de novo pelo botão da extensão, entra um gravador
  // novo e o popup manda "startRecording": sem tirar este ouvinte, o gravador
  // antigo também respondia e abria um segundo seletor de tela e uma segunda
  // reunião, invisível. Ver encerrarInstancia().
  const onMessage = (msg, _sender, sendResponse) => {
    if (msg.action === 'startRecording') startRecording();
    if (msg.action === 'stopRecording') stopRecording();
    // O popup confere se há mesmo uma gravação viva antes de mostrar "Enviando…".
    if (msg.action === 'status') {
      sendResponse({ recording: (!!mediaRecorder && mediaRecorder.state === 'recording') || coachAtivo, uploading, starting });
    }
  };
  chrome.runtime.onMessage.addListener(onMessage);
  window.__salescoachStartRecording = startRecording;
  // Usado pelo autodetect.js para parar quando a pessoa sai da chamada.
  window.__salescoachStopRecording = stopRecording;
  startRecording();

  // ── Auth helper ──
  /** fetch com prazo: rede ruim vira erro visível, não espera infinita. */
  async function fetchWithTimeout(url, opts, ms) {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), ms);
    try {
      return await fetch(url, { ...opts, signal: ctrl.signal });
    } catch (err) {
      if (err?.name === 'AbortError') throw new Error('O servidor demorou demais para responder.');
      throw err;
    } finally {
      clearTimeout(t);
    }
  }

  async function refreshAccessToken() {
    try {
      const data = await chrome.storage.local.get(['refreshToken']);
      if (!data.refreshToken) return null;
      const res = await fetchWithTimeout(`${SUPABASE_URL}/auth/v1/token?grant_type=refresh_token`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', apikey: SUPABASE_ANON_KEY },
        body: JSON.stringify({ refresh_token: data.refreshToken }),
      }, 20000);
      if (!res.ok) return null;
      const r = await res.json();
      chrome.storage.local.set({ accessToken: r.access_token, refreshToken: r.refresh_token });
      return r.access_token;
    } catch { return null; }
  }

  async function getValidToken() {
    try {
      const data = await chrome.storage.local.get(['accessToken']);
      const fresh = await refreshAccessToken();
      lastToken = fresh || data.accessToken || lastToken;
    } catch (err) {
      // Extensão recarregada durante a reunião: chrome.storage deixa de
      // responder nesta aba. Segue com o último token conhecido.
      console.warn('Sales Coach: sem acesso ao armazenamento da extensão:', err?.message || err);
    }
    return lastToken;
  }

  // ── Pre-create meeting (status=ao_vivo) so live channel works ──
  async function preCreateMeeting(token, meta) {
    const userId = (await chrome.storage.local.get(['userId'])).userId;
    const linha = {
      title: meta.title || 'Gravação ao vivo',
      meeting_type: meta.meetingType || null,
      lead_name: meta.leadName || null,
      lead_company: meta.leadCompany || null,
      lead_email: meta.leadEmail || null,
      meeting_url: meta.meetingUrl || location.href,
      calendar_event_id: meta.calendarEventId || null,
      attendees: meta.attendees?.length ? meta.attendees : null,
      status: 'ao_vivo',
      meeting_date: new Date().toISOString(),
      seller_id: userId,
      // Só o coach ao vivo: a gravação do robô entra nesta reunião.
      ...(meta.meetingBotId ? { meeting_bot_id: meta.meetingBotId } : {}),
      // Versão da extensão que gravou (tela Plataforma e investigação de erros).
      extensao_versao: chrome.runtime.getManifest().version,
    };
    const criar = (row) => fetchWithTimeout(`${SUPABASE_URL}/rest/v1/meetings`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
        apikey: SUPABASE_ANON_KEY,
        Prefer: 'return=representation',
      },
      body: JSON.stringify([row]),
    }, 20000);
    let res = await criar(linha);
    let body = res.ok ? null : await res.text();
    // Banco ainda sem a coluna da versão (migração não aplicada): grava sem ela,
    // para a versão nunca impedir uma gravação.
    if (!res.ok && /extensao_versao/.test(body)) {
      const { extensao_versao: _semVersao, ...semVersao } = linha;
      res = await criar(semVersao);
      body = res.ok ? null : await res.text();
    }
    if (!res.ok) {
      console.error('preCreateMeeting failed', res.status, body);
      let msg = '';
      try { msg = JSON.parse(body).message || ''; } catch {}
      throw new Error(friendlyCreateError(res.status, msg));
    }
    const rows = await res.json();
    return rows?.[0]?.id || null;
  }


  function friendlyCreateError(status, msg) {
    if (/row-level security/i.test(msg)) {
      return 'sua conta não tem permissão para criar reuniões agora. Se você é operador da plataforma, saia do modo suporte no Sales Coach e tente de novo.';
    }
    if (status === 401) return 'sessão expirada. Saia e entre de novo na extensão.';
    return `não foi possível criar a reunião (${status}${msg ? `: ${msg}` : ''}).`;
  }

  // ── Recording ──
  async function startRecording() {
    // Painel já fechado: esta instância terminou; quem grava é a nova.
    if (!overlay.isConnected) return;
    // Duas gravações ao mesmo tempo produzem um arquivo ilegível. Se já há uma
    // em curso, mantém a que está rodando.
    if (starting || coachAtivo || (mediaRecorder && mediaRecorder.state === 'recording')) {
      console.warn('Sales Coach: já existe uma gravação em curso; o pedido foi ignorado.');
      return;
    }
    starting = true;
    try {
      await beginRecording();
    } finally {
      starting = false;
    }
  }

  // Vídeo da tela, quando a pessoa escolhe gravar a tela: 540p a 5 quadros/s.
  // Gravar a aba obriga o Chrome a desenhá-la a todo vapor; somado ao Meet
  // apresentando slides, travava notebooks comuns. A análise usa só o áudio.
  const VIDEO_TELA = { width: { max: 960 }, height: { max: 540 }, frameRate: { max: 5 } };
  // Só o áudio da aba: o Chrome exige pedir vídeo junto; ele é descartado na hora.
  const VIDEO_MINIMO = { width: { max: 320 }, height: { max: 180 }, frameRate: { max: 1 } };

  async function pedirTela(comVideo = true) {
    try {
      return await navigator.mediaDevices.getDisplayMedia({
        video: comVideo ? VIDEO_TELA : VIDEO_MINIMO,
        audio: true,
        // Abre a escolha já na aba da reunião, com o áudio da aba: um clique
        // em "Compartilhar".
        preferCurrentTab: true,
      });
    } catch (err) {
      console.warn('Screen denied:', err.message);
      return null;
    }
  }

  async function querGravarTela() {
    try {
      const { meetingData, gravarTela } = await chrome.storage.local.get(['meetingData', 'gravarTela']);
      if (typeof meetingData?.gravarTela === 'boolean') return meetingData.gravarTela;
      return gravarTela === true;
    } catch { return false; }
  }

  /** A tela foi recusada: tentar de novo (o clique libera a janela do Chrome) ou seguir só com o áudio. */
  function escolherSemTela() {
    return new Promise((resolve) => {
      initEl.className = 'sc-status error';
      initEl.textContent = temAudioDaChamada()
        ? 'A tela não foi compartilhada. Sem ela, a gravação fica sem vídeo.'
        : 'A tela não foi compartilhada. Sem ela, a gravação fica sem vídeo e sem a voz do cliente.';
      const tela = document.createElement('button');
      tela.type = 'button';
      tela.className = 'sc-btn sc-btn-primary';
      tela.textContent = 'Compartilhar a tela';
      const audio = document.createElement('button');
      audio.type = 'button';
      audio.className = 'sc-btn';
      audio.textContent = temAudioDaChamada() ? 'Gravar só o áudio' : 'Gravar só o meu áudio';
      const hint = document.createElement('div');
      hint.className = 'sc-hint';
      hint.textContent = 'Escolha a aba da reunião e deixe "Compartilhar áudio da guia" ligado.';
      const fim = (escolha) => {
        tela.remove(); audio.remove(); hint.remove();
        initEl.className = 'sc-status sending';
        initEl.textContent = 'Escolha a aba da reunião e clique em Compartilhar.';
        resolve(escolha);
      };
      tela.addEventListener('click', () => fim('tela'));
      audio.addEventListener('click', () => fim('audio'));
      initEl.after(tela, audio, hint);
    });
  }

  async function beginRecording() {

    let hasScreen = false, hasSystemAudio = false;
    initEl.hidden = false;
    recordingEl.hidden = true;
    statusMsgEl.hidden = true;
    let meta = {};
    try { meta = (await chrome.storage.local.get(['meetingData'])).meetingData || {}; } catch {}
    soCoach = meta.soCoach === true;

    // Por padrão grava só o áudio: microfone (vendedor) + a voz do cliente que
    // chega pela chamada. Sem seletor de tela e quase sem peso no computador.
    // A tela só entra se a pessoa marcou "Gravar também a tela".
    if (!soCoach && await querGravarTela()) {
      initEl.textContent = 'Escolha a aba da reunião e clique em Compartilhar.';
      screenStream = await pedirTela(true);
      while (!screenStream) {
        if (await escolherSemTela() !== 'tela') break;
        screenStream = await pedirTela(true);
      }
    } else if (!temAudioDaChamada()) {
      // A extensão não está ouvindo a chamada (instalada ou atualizada com a
      // reunião já aberta). Com ela ouvindo, o cliente entra sozinho quando
      // chegar na sala. Sem ela, pega o áudio da aba e descarta o vídeo.
      initEl.textContent = soCoach
        ? 'Para ouvir o cliente, escolha a aba da reunião e clique em Compartilhar. Nada é gravado.'
        : 'Para ouvir o cliente, escolha a aba da reunião e clique em Compartilhar. Só o áudio é gravado.';
      screenStream = await pedirTela(false);
      if (screenStream) {
        for (const t of screenStream.getVideoTracks()) { t.stop(); screenStream.removeTrack(t); }
      }
    } else {
      initEl.textContent = soCoach ? 'Ligando as dicas ao vivo…' : 'Iniciando a gravação…';
    }
    if (screenStream) {
      hasScreen = screenStream.getVideoTracks().length > 0;
      hasSystemAudio = screenStream.getAudioTracks().length > 0;
      screenStream.getVideoTracks()[0]?.addEventListener('ended', () => stopRecording());
    }

    try {
      micStream = await abrirMicrofone(microfoneDaChamada());
    } catch (err) {
      if (!hasScreen) {
        showStatus('error', '❌ Permissões negadas.');
        autoRemove(6000); return;
      }
    }
    if (!screenStream && !micStream && !temAudioDaChamada()) {
      showStatus('error', '❌ Nenhuma fonte disponível.'); autoRemove(6000); return;
    }

    audioContext = new AudioContext();
    // Criado depois do seletor de tela, o contexto pode nascer suspenso e
    // gravar silêncio: retoma já.
    audioContext.resume().catch(() => {});
    const mixedDest = mixDest = audioContext.createMediaStreamDestination();
    if (micStream) {
      micSource = audioContext.createMediaStreamSource(micStream);
      micSource.connect(mixedDest);
    }
    clienteMix = montarCliente(audioContext, hasSystemAudio ? new MediaStream(screenStream.getAudioTracks()) : null);
    if (clienteMix) clienteMix.saida.connect(mixedDest);
    const clienteStream = clienteMix ? clienteMix.stream : null;

    if (soCoach) { await iniciarSoCoach(meta, clienteStream, hasSystemAudio); return; }

    const tracks = [...mixedDest.stream.getAudioTracks()];
    if (hasScreen) tracks.unshift(...screenStream.getVideoTracks());
    const combinedStream = new MediaStream(tracks);

    const isVideo = hasScreen && screenStream.getVideoTracks().length > 0;
    // H.264 costuma ser comprimido pelo chip de vídeo; VP8 vai todo para o processador.
    const mimeType = isVideo
      ? (['video/webm;codecs=h264,opus', 'video/webm;codecs=vp8,opus'].find((t) => MediaRecorder.isTypeSupported(t)) || 'video/webm')
      : 'audio/webm;codecs=opus';
    const mode = isVideo ? 'screen_audio' : 'audio_only';

    // Os pedaços ficam presos a ESTA gravação. Antes eram empurrados para uma
    // variável do módulo: se uma gravação anterior ainda estivesse viva, os
    // pedaços dela caíam aqui também e o arquivo virava a cauda de um stream
    // colada na frente de outro — sem cabeçalho, ilegível.
    const chunks = [];
    recordedChunks = chunks;
    mediaRecorder = new MediaRecorder(combinedStream, {
      mimeType, ...(isVideo ? { videoBitsPerSecond: 450_000 } : {}),
    });
    const meuRecorder = mediaRecorder;
    mediaRecorder.ondataavailable = (e) => {
      // Só aceita pedaço do gravador atual: um gravador antigo que ainda não
      // parou não contamina o arquivo novo.
      if (e.data.size > 0 && mediaRecorder === meuRecorder) chunks.push(e.data);
    };
    mediaRecorder.onstop = async () => {
      try {
        await finishRecording();
      } catch (err) {
        // Qualquer falha aqui deixava o painel parado em "Enviando gravação…".
        console.error('Sales Coach: falha ao finalizar a gravação:', err);
        cleanup();
        const rescued = await rescueFromBackup();
        uploading = false;
        const msg = err?.message || String(err);
        failWithDownload(chunks, mimeType, rescued ? `O vídeo não foi enviado (${msg}), mas o áudio foi para análise.` : msg, rescued);
      }
    };

    const finishRecording = async () => {
      showStatus('sending', 'Enviando gravação...');
      notifyBackground('uploadStarted');
      stopLive();
      if (chunks.length === 0) { showStatus('error', '❌ Nada gravado.'); cleanup(); autoRemove(6000); return; }
      const blob = new Blob(chunks, { type: chunks[0]?.type || mimeType });
      if (blob.size < 100) { showStatus('error', '❌ Gravação vazia.'); cleanup(); autoRemove(6000); return; }

      // Um webm começa com a assinatura EBML (1A 45 DF A3). Se o arquivo não
      // começar assim, ele perdeu o cabeçalho e nenhum serviço vai conseguir
      // ler: melhor avisar aqui do que subir 10 MB que voltam como erro.
      if (isVideo || mimeType.includes('webm')) {
        const inicio = new Uint8Array(await blob.slice(0, 4).arrayBuffer());
        const ebml = inicio[0] === 0x1a && inicio[1] === 0x45 && inicio[2] === 0xdf && inicio[3] === 0xa3;
        if (!ebml) {
          console.error('Sales Coach: gravação sem cabeçalho EBML, não será enviada.');
          cleanup();
          if (await rescueFromBackup()) {
            showStatus('success', 'A gravação de vídeo saiu corrompida, mas o áudio foi enviado para análise.');
            notifyBackground('uploadComplete', { meetingId });
            autoRemove(8000); return;
          }
          showStatus('error', '❌ A gravação saiu corrompida e não foi enviada. Grave de novo, com uma gravação por vez.');
          autoRemove(9000); return;
        }
      }
      cleanup();
      await uploadRecording(blob);
    };
    mediaRecorder.start(1000);

    startTime = Date.now();
    initEl.hidden = true;
    recordingEl.hidden = false;
    recEl.hidden = false;
    stopBtn.hidden = false;
    recEl.title = isVideo ? 'Gravando tela e áudio' : 'Gravando só o áudio';
    startTimer();
    startMeters(micStream, clienteStream);
    if (!hasSystemAudio && !temAudioDaChamada()) {
      setAlert('sem-cliente', {
        kind: 'warn', title: 'Não estou ouvindo o cliente',
        text: 'Só a sua voz entra. Compartilhe a aba da reunião com "Compartilhar áudio da guia" marcado; a gravação continua.',
        action: OUVIR_PELA_ABA,
      });
    }
    safeStorageSet({
      recordingState: 'recording', recordingStartTime: startTime,
      recordingMode: mode, isScreenSharing: isVideo,
    });
    notifyBackground('recordingStarted', { mode, startTime });

    // ── Live coach pipeline ──
    setLiveText('Conectando a transcrição…');
    setTipsStatus('Conectando o coach…');
    try {
      const token = await getValidToken();
      if (!token) throw new Error('sessão expirada — refaça login na extensão');
      const data = await chrome.storage.local.get(['meetingData']);
      meetingId = await preCreateMeeting(token, data.meetingData || {});
      if (meetingId) {
        chrome.storage.local.set({ lastMeetingId: meetingId });
        // Cópia do áudio subindo aos poucos: protege a reunião se a aba fechar.
        startBackup(mixedDest.stream, meetingId);
        // Microfone = vendedor; áudio da aba = cliente. Sem o áudio da aba,
        // só a trilha do vendedor entra.
        await startLive(token, meetingId, {
          vendedor: micStream,
          cliente: clienteStream,
        });
      } else {
        throw new Error('não foi possível criar a reunião.');
      }
    } catch (e) {
      dicasOff(e, 'A gravação continua normalmente e a análise sai no final.', {
        vendedor: micStream,
        cliente: clienteStream,
      });
    }
  }

  // As dicas não ligaram, mas a gravação segue. O aviso mostra o motivo e, se
  // a reunião já existe, deixa tentar de novo sem parar a gravação (ex.: o
  // crédito da transcrição foi recarregado no meio da chamada).
  let religandoDicas = false;
  function dicasOff(e, texto, streams) {
    console.warn('Live coach off:', e);
    setLiveText('Transcrição ao vivo desligada nesta reunião.');
    setTipsStatus(null);
    tipsEl.innerHTML = '';
    setAlert('live-off', {
      kind: 'warn', title: 'Dicas ao vivo indisponíveis', text: texto,
      detail: String(e?.message || e),
      action: meetingId ? { label: 'Tentar de novo', onClick: () => religarDicas(texto, streams) } : null,
    });
  }

  async function religarDicas(texto, streams) {
    const gravando = coachAtivo || (mediaRecorder && mediaRecorder.state === 'recording');
    if (religandoDicas || !gravando || !meetingId) return;
    religandoDicas = true;
    setAlert('live-off', null);
    setLiveText('Conectando a transcrição…');
    setTipsStatus('Conectando o coach…');
    try {
      const token = await getValidToken();
      if (!token) throw new Error('sessão expirada — refaça login na extensão');
      await startLive(token, meetingId, streams);
    } catch (e) {
      dicasOff(e, texto, streams);
    } finally {
      religandoDicas = false;
    }
  }

  // ── Só o coach ao vivo ──
  //
  // O vendedor escolheu o robô de reunião para esta chamada: o robô grava (áudio
  // e vídeo, pelos servidores) e a extensão só ouve para as dicas ao vivo. Sem
  // gravador, sem cópia em partes e sem envio no fim: nada pesa no computador.
  // A reunião criada aqui leva meeting_bot_id, e a gravação do robô entra nela
  // quando a chamada acaba (meeting-bot-webhook).
  async function iniciarSoCoach(meta, clienteStream, hasSystemAudio) {
    coachAtivo = true;
    startTime = Date.now();
    initEl.hidden = true;
    recordingEl.hidden = false;
    recEl.hidden = false;
    recEl.classList.add('sc-coach');
    // "AO VIVO 00:00" é mais largo que "REC": o logo basta no cabeçalho.
    overlay.classList.add('sc-modo-coach');
    recEl.querySelector('span').firstChild.nodeValue = 'AO VIVO ';
    recEl.title = 'Só as dicas ao vivo: quem grava é o robô';
    stopBtn.hidden = false;
    stopBtn.title = 'Encerrar as dicas';
    stopBtn.setAttribute('aria-label', 'Encerrar as dicas');
    startTimer();
    startMeters(micStream, clienteStream);
    if (!hasSystemAudio && !temAudioDaChamada()) {
      setAlert('sem-cliente', {
        kind: 'warn', title: 'Não estou ouvindo o cliente',
        text: 'As dicas usam só a sua voz. Compartilhe a aba da reunião com "Compartilhar áudio da guia" marcado.',
        action: OUVIR_PELA_ABA,
      });
    }
    safeStorageSet({ recordingState: 'recording', recordingStartTime: startTime, recordingMode: 'coach', isScreenSharing: false });
    notifyBackground('coachStarted', { mode: 'coach', startTime });

    setLiveText('Conectando a transcrição…');
    setTipsStatus('Conectando o coach…');
    try {
      const token = await getValidToken();
      if (!token) throw new Error('sessão expirada — refaça login na extensão');
      meetingId = await preCreateMeeting(token, meta);
      if (!meetingId) throw new Error('não foi possível criar a reunião.');
      chrome.storage.local.set({ lastMeetingId: meetingId });
      await startLive(token, meetingId, { vendedor: micStream, cliente: clienteStream });
    } catch (e) {
      dicasOff(e, 'O robô continua gravando e a análise sai no final.', { vendedor: micStream, cliente: clienteStream });
    }
  }

  function encerrarCoach() {
    coachAtivo = false;
    recordingEl.hidden = true;
    stopLive();
    cleanup();
    safeStorageSet({ recordingState: 'idle' });
    try { chrome.storage.local.remove(['recordingStartTime', 'recordingMode']); } catch {}
    notifyBackground('coachEnded', { meetingId });
    showStatus('success', 'Dicas encerradas. A análise vem da gravação do robô, alguns minutos depois que a reunião acabar.');
    autoRemove(7000);
  }

  function stopRecording() {
    if (coachAtivo) { encerrarCoach(); return; }
    if (mediaRecorder && mediaRecorder.state !== 'inactive') {
      mediaRecorder.stop();
      recordingEl.hidden = true;
    }
    // A última parte do áudio sobe já: se a aba fechar durante o envio da
    // gravação principal, a cópia está completa.
    stopBackup();
  }

  // ── Cópia do áudio em partes ──
  //
  // Em paralelo à gravação principal (tela + áudio, enviada no fim), grava só
  // o áudio e sobe uma parte a cada 30 s para a função recording-parts. Se a
  // aba ou o navegador fecham antes do envio, o background pede ao servidor
  // que junte as partes e mande o áudio para análise. Com a gravação
  // principal enviada, o servidor apaga as partes.
  const BACKUP_SLICE_MS = 30000;
  let backup = null; // { recorder, meetingId, next, queue, sending, done }

  function startBackup(stream, mid) {
    const tracks = stream.getAudioTracks();
    if (!tracks.length || backup) return;
    try {
      const recorder = new MediaRecorder(new MediaStream(tracks), {
        mimeType: 'audio/webm;codecs=opus', audioBitsPerSecond: 32000,
      });
      const b = backup = { recorder, meetingId: mid, next: 0, queue: [], sending: null, stopped: null };
      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) { b.queue.push({ index: b.next++, blob: e.data }); pumpBackup(b); }
      };
      b.stopped = new Promise((resolve) => { recorder.onstop = resolve; });
      recorder.start(BACKUP_SLICE_MS);
      notifyBackground('backupStarted', { meetingId: mid });
    } catch (e) {
      console.warn('Sales Coach: cópia do áudio indisponível', e);
      backup = null;
    }
  }

  function stopBackup() {
    if (backup && backup.recorder.state !== 'inactive') {
      try { backup.recorder.stop(); } catch {}
    }
  }

  /** Sobe as partes na ordem; parte que falha tenta de novo na próxima vez. */
  function pumpBackup(b) {
    if (b.sending || !b.queue.length) return b.sending;
    b.sending = (async () => {
      while (b.queue.length) {
        const part = b.queue[0];
        try {
          const res = await authed(
            `/functions/v1/recording-parts?meetingId=${encodeURIComponent(b.meetingId)}&part=${part.index}`,
            { method: 'POST', headers: { 'Content-Type': 'application/octet-stream' }, body: part.blob },
            60000,
          );
          if (!res.ok && res.status !== 413) throw new Error(`status ${res.status}`);
          b.queue.shift();
        } catch (e) {
          console.warn('Sales Coach: parte do áudio não subiu, tentando de novo depois', part.index, e);
          break;
        }
      }
      b.sending = null;
    })();
    return b.sending;
  }

  /**
   * A gravação principal não chegou ao servidor: manda a cópia do áudio para
   * análise. Devolve true se o servidor aceitou.
   */
  async function rescueFromBackup() {
    const b = backup;
    if (!b) return false;
    try {
      stopBackup();
      await Promise.race([b.stopped, new Promise((r) => setTimeout(r, 3000))]);
      for (let i = 0; i < 3 && (b.queue.length || b.sending); i++) {
        await (b.sending || pumpBackup(b));
      }
      const res = await authed('/functions/v1/recording-parts', {
        method: 'POST', body: JSON.stringify({ action: 'finish', meetingId: b.meetingId }),
      }, 120000);
      const data = await res.json().catch(() => ({}));
      if (res.ok) notifyBackground('backupFinished', { meetingId: b.meetingId });
      return res.ok && !!data.finished;
    } catch (e) {
      console.warn('Sales Coach: cópia do áudio não foi enviada', e);
      return false;
    }
  }

  // Fechar a aba com a gravação rodando ou subindo: o Chrome pergunta antes.
  window.addEventListener('beforeunload', (e) => {
    const busy = (mediaRecorder && mediaRecorder.state === 'recording') || uploading;
    if (!busy) return;
    e.preventDefault();
    e.returnValue = 'A gravação ainda não foi enviada.';
  });
  // Saiu mesmo assim: o background junta o áudio que já subiu.
  window.addEventListener('pagehide', () => {
    if (backup && ((mediaRecorder && mediaRecorder.state === 'recording') || uploading)) {
      notifyBackground('recordingAbandoned', { meetingId: backup.meetingId });
    }
  });

  // ── Microfone ──
  //
  // O mesmo microfone que a chamada abriu (remote-audio.js marca o deviceId no
  // <html>). O padrão do Chrome pode ser outro aparelho, mudo: a voz do
  // vendedor sumia da gravação e das dicas. Sem a marca (extensão instalada com
  // a reunião aberta), fica o padrão, como antes.
  const AUDIO_MIC = { echoCancellation: true, noiseSuppression: true };
  function microfoneDaChamada() {
    try { return document.documentElement.dataset.scMicrofone || null; } catch { return null; }
  }
  function idDoMicrofone(stream) {
    try { return stream?.getAudioTracks()[0]?.getSettings?.().deviceId || null; } catch { return null; }
  }
  async function abrirMicrofone(deviceId) {
    if (deviceId && deviceId !== 'default') {
      try {
        const s = await navigator.mediaDevices.getUserMedia({ audio: { ...AUDIO_MIC, deviceId: { exact: deviceId } } });
        console.info('Sales Coach: microfone da chamada', idDoMicrofone(s));
        return s;
      } catch (e) {
        console.warn('Sales Coach: microfone da chamada indisponível, usando o padrão', e);
      }
    }
    const s = await navigator.mediaDevices.getUserMedia({ audio: AUDIO_MIC });
    console.info('Sales Coach: microfone padrão', idDoMicrofone(s));
    return s;
  }

  /** Troca o microfone sem parar a gravação nem as dicas ao vivo. */
  let trocandoMic = false;
  async function trocarMicrofone(deviceId) {
    if (trocandoMic || !audioContext || !mixDest) return false;
    trocandoMic = true;
    try {
      const novo = await abrirMicrofone(deviceId);
      if (!audioContext || !mixDest) { novo.getTracks().forEach((t) => t.stop()); return false; }
      const antigo = micStream;
      micStream = novo;
      try { micSource?.disconnect(); } catch {}
      micSource = audioContext.createMediaStreamSource(novo);
      micSource.connect(mixDest);
      const ch = liveChannels.vendedor;
      if (ch?.ctx && ch.ctx.state !== 'closed') {
        try { ch.source?.disconnect(); } catch {}
        ch.stream = novo;
        ch.source = ch.ctx.createMediaStreamSource(novo);
        if (ch.processor) ch.source.connect(ch.processor);
      }
      startMeters(micStream, clienteMix ? clienteMix.stream : null);
      setAlert('mic-mudo', null);
      antigo?.getTracks().forEach((t) => t.stop());
      return true;
    } catch (e) {
      console.warn('Sales Coach: não foi possível trocar o microfone', e);
      return false;
    } finally {
      trocandoMic = false;
    }
  }
  // O vendedor trocou de microfone nas configurações do Meet: a extensão acompanha.
  const vigiaMic = new MutationObserver(() => {
    const id = microfoneDaChamada();
    const gravando = coachAtivo || (mediaRecorder && mediaRecorder.state === 'recording');
    if (id && gravando && id !== idDoMicrofone(micStream)) trocarMicrofone(id);
  });
  try { vigiaMic.observe(document.documentElement, { attributes: true, attributeFilter: ['data-sc-microfone'] }); } catch {}

  function cleanup() {
    stopTimer();
    stopMeters();
    if (micStream) { micStream.getTracks().forEach(t => t.stop()); micStream = null; }
    if (screenStream) { screenStream.getTracks().forEach(t => t.stop()); screenStream = null; }
    if (clienteMix) { clienteMix.parar(); clienteMix = null; }
    if (audioContext) { audioContext.close().catch(() => {}); audioContext = null; }
    mixDest = null;
    micSource = null;
    recordedChunks = [];
  }

  // ── Voz do cliente ──
  //
  // Duas fontes possíveis: o áudio que chega pela chamada (remote-audio.js,
  // não depende do alto-falante: funciona com o vendedor de fone) e o áudio
  // da aba compartilhada. Grava UMA delas por vez, para a voz não sair
  // duplicada: a chamada tem preferência; a aba só entra se a chamada não
  // trouxer som nenhum (por exemplo, extensão atualizada no meio da reunião).
  //
  // As trilhas da chamada vêm de dois lugares: o gancho (remote-audio.js) e os
  // próprios <audio>/<video> em que o Meet e o Teams tocam a chamada. O
  // segundo cobre o caso em que o gancho não pegou a conexão. Microfone fica
  // de fora: trilha capturada no computador tem o nome do aparelho no label;
  // trilha que chega pela chamada tem um identificador (o próprio id) no lugar.
  const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  const daChamada = (t) => !t.label || t.label === t.id || UUID.test(t.label) || /remote/i.test(t.label);
  function faixasDaChamada() {
    const faixas = new Map();
    const meus = new Set(micStream ? micStream.getAudioTracks().map((t) => t.id) : []);
    const juntar = (s, doGancho) => {
      if (!s || typeof s.getAudioTracks !== 'function') return;
      for (const t of s.getAudioTracks()) {
        if (t.readyState !== 'live' || faixas.has(t.id) || meus.has(t.id)) continue;
        if (doGancho || daChamada(t)) faixas.set(t.id, t);
      }
    };
    juntar(document.getElementById('sc-remote-audio')?.srcObject, true);
    for (const m of document.querySelectorAll('audio, video')) {
      try { juntar(m.srcObject); } catch {}
    }
    return [...faixas.values()];
  }
  /** A extensão consegue ouvir a chamada nesta aba (gancho instalado ou chamada já tocando). */
  function temAudioDaChamada() {
    return !!document.getElementById('sc-remote-audio') || faixasDaChamada().length > 0;
  }

  const CLIENTE_TROCA_MS = 12000;
  function montarCliente(ctx, aba) {
    // Sem nenhuma fonte agora, o mix nasce vazio: a aba pode entrar depois
    // (botão "Ouvir pela aba" no painel).
    const chamada = temAudioDaChamada();
    const dest = ctx.createMediaStreamDestination();
    const saida = ctx.createGain();
    saida.connect(dest);
    const fontes = {};
    const nova = (nome) => {
      const soma = ctx.createGain();
      const ganho = ctx.createGain();
      const a = ctx.createAnalyser();
      a.fftSize = 1024;
      soma.connect(a);
      soma.connect(ganho);
      ganho.connect(saida);
      ganho.gain.value = 0;
      return (fontes[nome] = { soma, ganho, a, buf: new Float32Array(1024), ultimoSom: 0 });
    };
    if (aba) ctx.createMediaStreamSource(aba).connect(nova('aba').soma);
    const ligadas = new Map();
    if (chamada) nova('chamada');
    // As trilhas da chamada mudam (gente entra e sai): liga as novas a cada segundo.
    const ligar = () => {
      if (!fontes.chamada) return;
      const vivas = new Map(faixasDaChamada().map((t) => [t.id, t]));
      for (const t of vivas.values()) {
        if (ligadas.has(t.id)) continue;
        try {
          const src = ctx.createMediaStreamSource(new MediaStream([t]));
          src.connect(fontes.chamada.soma);
          ligadas.set(t.id, { src, t });
        } catch (e) { console.warn('Sales Coach: trilha da chamada não ligou', e); }
      }
      for (const [id, l] of ligadas) {
        if (l.t.readyState === 'ended') { try { l.src.disconnect(); } catch {} ligadas.delete(id); }
      }
    };
    let atual = chamada ? 'chamada' : 'aba';
    let inicio = Date.now();
    const usar = (nome) => {
      atual = nome;
      for (const [n, f] of Object.entries(fontes)) f.ganho.gain.setTargetAtTime(n === nome ? 1 : 0, ctx.currentTime, 0.05);
      console.info(`Sales Coach: voz do cliente vindo da ${nome === 'chamada' ? 'chamada' : 'aba compartilhada'}`);
    };
    usar(atual);
    const timer = setInterval(() => {
      if (ctx.state === 'suspended') ctx.resume().catch(() => {});
      ligar();
      const agora = Date.now();
      for (const f of Object.values(fontes)) {
        f.a.getFloatTimeDomainData(f.buf);
        let soma = 0;
        for (let i = 0; i < f.buf.length; i++) soma += f.buf[i] * f.buf[i];
        if (Math.sqrt(soma / f.buf.length) > 0.01) f.ultimoSom = agora;
      }
      // A chamada tem preferência: com som, volta para ela na hora. A aba só
      // assume se a chamada nunca teve som e a aba tem.
      if (atual === 'aba' && fontes.chamada && agora - fontes.chamada.ultimoSom < 1500) usar('chamada');
      else if (atual === 'chamada' && fontes.aba && !fontes.chamada.ultimoSom
        && agora - inicio > CLIENTE_TROCA_MS && agora - fontes.aba.ultimoSom < 2000) usar('aba');
    }, 1000);
    ligar();
    return {
      stream: dest.stream, saida,
      /** Quantas trilhas da chamada estão ligadas e quando a chamada teve som pela última vez. */
      estado: () => ({ trilhas: ligadas.size, somChamada: fontes.chamada?.ultimoSom || 0, temAba: !!fontes.aba }),
      /** Áudio da aba compartilhado no meio da gravação: entra como reserva da chamada. */
      adicionarAba(stream) {
        if (fontes.aba) return;
        ctx.createMediaStreamSource(stream).connect(nova('aba').soma);
        // A chamada que nunca teve som cede a vez à aba logo que ela tiver som.
        inicio = Date.now() - CLIENTE_TROCA_MS;
        if (!fontes.chamada?.ultimoSom) usar('aba');
      },
      parar() {
        clearInterval(timer);
        for (const l of ligadas.values()) { try { l.src.disconnect(); } catch {} }
        ligadas.clear();
      },
    };
  }

  // ── Live: AssemblyAI direto, uma conexão por trilha, + dicas em tempo real ──
  //
  // Antes o áudio passava por um WebSocket aberto numa edge function, que tem
  // tempo máximo de vida: o live parava sozinho no meio da reunião. Agora a
  // extensão conecta direto na AssemblyAI com um token temporário emitido pela
  // função live-session (a chave da AssemblyAI fica no servidor). Cada fala
  // concluída vira um trecho em transcription_segments, com quem falou, e
  // dispara o coach em chamadas curtas.

  // Versão própria para reunião em outro idioma (pacote de scripts/extensao-idioma.mjs):
  // transcreve no idioma da reunião, traduz para o português o que os outros
  // disseram e sopra a frase no idioma da reunião. null na versão da loja.
  const VARIANTE = null;
  const AAI_WS = `wss://streaming.assemblyai.com/v3/ws?speech_model=${VARIANTE ? 'universal-streaming-multilingual' : 'u3-rt-pro'}&encoding=pcm_s16le&sample_rate=16000&format_turns=true`;
  // Ritmo do coach. Depois da fala do cliente, chama logo (pode ser uma
  // objeção). Depois da fala do vendedor, espera: logo depois de uma dica ele
  // está lendo ou fazendo a pergunta sugerida, e a fala dele disparava uma
  // versão nova da mesma pergunta. Uma chamada por vez.
  const COACH_APOS_CLIENTE_MS = 2000;
  const COACH_APOS_VENDEDOR_MS = 20000;
  const LABEL = { vendedor: 'Você', cliente: VARIANTE?.outros || 'Cliente' };
  let lastCoachAt = 0;
  let coachTimer = null;
  let coachTimerAt = 0;
  let coachEmCurso = false;
  let coachPendente = null; // quem falou enquanto uma chamada estava em curso
  const liveLines = [];

  /** Chamada autenticada a uma função ou ao REST; renova a sessão uma vez se expirou. */
  async function authed(path, init = {}, ms = 20000) {
    const doFetch = (token) => fetchWithTimeout(`${SUPABASE_URL}${path}`, {
      ...init,
      headers: { 'Content-Type': 'application/json', apikey: SUPABASE_ANON_KEY, Authorization: `Bearer ${token}`, ...(init.headers || {}) },
    }, ms);
    let res = await doFetch(lastToken);
    if (res.status === 401) {
      const fresh = await refreshAccessToken();
      if (fresh) { lastToken = fresh; res = await doFetch(fresh); }
    }
    return res;
  }

  async function liveTokens(mid, channels) {
    const res = await authed('/functions/v1/live-session', {
      method: 'POST', body: JSON.stringify({ action: 'start', meetingId: mid, channels }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok || !data.tokens) throw new Error(data.error || `transcrição indisponível (${res.status})`);
    return data.tokens;
  }

  function lineHtml(who, text, pt) {
    return `<b>${escape(LABEL[who])}:</b> ${escape(text)}${pt ? `<span class="sc-pt">${escape(pt)}</span>` : ''}`;
  }
  function renderLive(partial) {
    const last = partial ? { ...partial, text: `${partial.text}…` } : liveLines[liveLines.length - 1];
    if (last) liveTextEl.innerHTML = lineHtml(last.who, last.text, last.pt);
    else setLiveText('Conectado. Aguardando a primeira fala…');
    const all = liveLines.map((l) => `<div>${lineHtml(l.who, l.text, l.pt)}</div>`);
    if (partial) all.push(`<div>${lineHtml(partial.who, `${partial.text}…`)}</div>`);
    const atEnd = txFullEl.scrollHeight - txFullEl.scrollTop - txFullEl.clientHeight < 24;
    txFullEl.innerHTML = all.join('') || '<div>Nenhuma fala ainda.</div>';
    if (atEnd) txFullEl.scrollTop = txFullEl.scrollHeight;
  }

  async function saveSegment(mid, who, text) {
    try {
      // org_id é preenchido pelo banco a partir da reunião.
      await authed('/rest/v1/transcription_segments', {
        method: 'POST',
        headers: { Prefer: 'return=minimal' },
        body: JSON.stringify({ meeting_id: mid, text, is_final: true, speaker: who }),
      });
    } catch (e) {
      console.warn('Sales Coach: trecho não salvo', e);
    }
    scheduleCoach(mid, who);
  }

  function scheduleCoach(mid, who) {
    if (coachEmCurso) {
      // Roda de novo quando a chamada atual voltar; a fala do cliente tem prioridade.
      if (!coachPendente || who === 'cliente') coachPendente = who;
      return;
    }
    const gap = who === 'cliente' ? COACH_APOS_CLIENTE_MS : COACH_APOS_VENDEDOR_MS;
    const wait = Math.max(0, gap - (Date.now() - lastCoachAt));
    // Já tem uma chamada marcada: só adianta (fala do cliente), nunca atrasa.
    if (coachTimer) {
      if (Date.now() + wait >= coachTimerAt) return;
      clearTimeout(coachTimer);
    }
    coachTimerAt = Date.now() + wait;
    coachTimer = setTimeout(() => runCoach(mid, who), wait);
  }

  async function runCoach(mid, who) {
    coachTimer = null;
    if (liveStopping) return;
    coachEmCurso = true;
    lastCoachAt = Date.now();
    // Na versão de outro idioma, vão junto as falas dos outros ainda sem tradução.
    const falas = VARIANTE ? liveLines.filter((l) => l.who === 'cliente' && !l.pt && !l.pedida) : [];
    falas.forEach((l) => { l.pedida = true; });
    try {
      const res = await authed('/functions/v1/live-coach', {
        method: 'POST',
        body: JSON.stringify({
          meetingId: mid, gatilho: who,
          ...(VARIANTE ? { idioma: VARIANTE.idioma, contexto: VARIANTE.contexto, falas: falas.map((l) => l.text) } : {}),
        }),
      }, 30000);
      if (falas.length) {
        const d = await res.json().catch(() => ({}));
        (d.traducoes || []).forEach((t, i) => { if (falas[i] && t) falas[i].pt = String(t); });
        renderLive(null);
      }
    } catch { /* sem dica desta vez */ }
    falas.forEach((l) => { if (!l.pt) l.pedida = false; });
    coachEmCurso = false;
    if (coachPendente && !liveStopping) {
      const quem = coachPendente;
      coachPendente = null;
      scheduleCoach(mid, quem);
    }
  }

  function openChannel(mid, who, stream, token, attempt = 0) {
    const ch = liveChannels[who] || (liveChannels[who] = { who, stream, attempts: 0 });
    ch.attempts = attempt;

    // Áudio: PCM16 16 kHz mono, só desta trilha.
    if (!ch.ctx) {
      ch.ctx = new AudioContext({ sampleRate: 16000 });
      ch.ctx.resume().catch(() => {});
      ch.source = ch.ctx.createMediaStreamSource(stream);
      ligarPcm(ch);
    }

    const ws = new WebSocket(`${AAI_WS}&token=${encodeURIComponent(token)}`);
    ws.binaryType = 'arraybuffer';
    ch.ws = ws;
    ws.onopen = () => {
      ch.attempts = 0;
      ch.down = false;
      if (!Object.values(liveChannels).some((c) => c.down)) setAlert('reconectando', null);
      if (!liveLines.length) renderLive(null);
    };
    ws.onmessage = (ev) => {
      try {
        const m = JSON.parse(ev.data);
        if (m.type !== 'Turn') return;
        const text = (m.transcript || '').trim();
        if (!text) return;
        if (m.end_of_turn) {
          liveLines.push({ who, text });
          if (liveLines.length > 60) liveLines.shift();
          renderLive(null);
          if (text.length > 2) saveSegment(mid, who, text);
          if (who === 'vendedor') falaDoVendedor(text);
        } else {
          renderLive({ who, text });
        }
      } catch {}
    };
    ws.onclose = (ev) => {
      if (liveStopping || ch.ws !== ws) return;
      console.warn(`Sales Coach: trilha ${who} caiu (${ev.code} ${ev.reason || ''}); reconectando`);
      ch.down = true;
      setAlert('reconectando', RECONNECTING);
      // Reconecta com um token novo, com espera crescente (1, 2, 4... até 30 s).
      const delay = Math.min(30000, 1000 * 2 ** ch.attempts);
      setTimeout(async () => {
        if (liveStopping) return;
        try {
          const tokens = await liveTokens(mid, [who]);
          openChannel(mid, who, stream, tokens[who], ch.attempts + 1);
        } catch (e) {
          console.warn('Sales Coach: reconexão falhou', e);
          ch.attempts += 1;
          ws.onclose({ code: 0, reason: 'retry' });
        }
      }, delay);
    };
  }

  // A conversão para PCM roda num AudioWorklet, na thread de áudio, fora da
  // thread do Meet. Se o worklet não carregar, volta ao ScriptProcessorNode
  // (obsoleto, roda na thread da página, mas funciona).
  const enviar = (ch, buf) => { if (ch.ws && ch.ws.readyState === 1) ch.ws.send(buf); };
  async function ligarPcm(ch) {
    try {
      await ch.ctx.audioWorklet.addModule(chrome.runtime.getURL('pcm-worklet.js'));
      if (!ch.ctx || ch.ctx.state === 'closed') return;
      ch.processor = new AudioWorkletNode(ch.ctx, 'salescoach-pcm', { numberOfInputs: 1, numberOfOutputs: 0 });
      ch.processor.port.onmessage = (e) => enviar(ch, e.data);
      ch.source.connect(ch.processor);
    } catch (e) {
      console.warn('Sales Coach: AudioWorklet indisponível, usando ScriptProcessor', e);
      if (!ch.ctx || ch.ctx.state === 'closed') return;
      try {
        ch.processor = ch.ctx.createScriptProcessor(4096, 1, 1);
        ch.source.connect(ch.processor);
        ch.processor.connect(ch.ctx.destination);
        ch.processor.onaudioprocess = (ev) => {
          const input = ev.inputBuffer.getChannelData(0);
          const pcm = new Int16Array(input.length);
          for (let i = 0; i < input.length; i++) {
            const v = Math.max(-1, Math.min(1, input[i]));
            pcm[i] = v < 0 ? v * 0x8000 : v * 0x7FFF;
          }
          enviar(ch, pcm.buffer);
        };
      } catch (e2) { console.warn('Sales Coach: trilha sem transcrição ao vivo', e2); }
    }
  }

  async function startLive(token, mid, streams) {
    lastToken = token;
    liveStopping = false;
    liveStartedAt = Date.now();
    const channels = Object.keys(streams).filter((k) => streams[k] && streams[k].getAudioTracks().length);
    if (!channels.length) throw new Error('sem áudio para transcrever');
    const tokens = await liveTokens(mid, channels);
    for (const who of channels) openChannel(mid, who, streams[who], tokens[who]);
    if (!channels.includes('cliente')) {
      // O aviso "Não estou ouvindo o cliente" já está no painel.
    }
    startTipsRealtime(token, mid);
    if (!roteiro.tipos.length) carregarRoteiro();
  }

  function nextRealtimeRef() { return String(realtimeRef++); }

  function sendRealtime(topic, event, payload = {}) {
    if (!tipsWS || tipsWS.readyState !== WebSocket.OPEN) return;
    tipsWS.send(JSON.stringify({ topic, event, payload, ref: nextRealtimeRef() }));
  }

  // Canal das dicas (Supabase Realtime). Antes, se a conexão caía (rede
  // instável) ou o login vencia (1 hora), as dicas paravam até o fim da
  // reunião, com o aviso "reconectando" parado na tela. Agora reconecta com
  // espera crescente e renova o login no canal antes de ele vencer.
  const TIPS_TOKEN_MS = 20 * 60 * 1000;
  let tipsTentativas = 0;
  let tipsTokenTimer = null;

  function startTipsRealtime(token, mid) {
    try {
      const topic = `realtime:tips-${mid}`;
      const url = `${SUPABASE_REALTIME_WS}?apikey=${encodeURIComponent(SUPABASE_ANON_KEY)}&vsn=1.0.0`;
      const ws = tipsWS = new WebSocket(url);
      let joinRef = null;

      ws.onopen = () => {
        joinRef = nextRealtimeRef();
        ws.send(JSON.stringify({
          topic, event: 'phx_join',
          payload: {
            access_token: token,
            config: {
              broadcast: { self: false },
              presence: { key: '' },
              postgres_changes: [
                { event: 'INSERT', schema: 'public', table: 'live_tips', filter: `meeting_id=eq.${mid}` },
              ],
            },
          },
          ref: joinRef,
        }));
        if (tipsHeartbeatInterval) clearInterval(tipsHeartbeatInterval);
        tipsHeartbeatInterval = setInterval(() => sendRealtime('phoenix', 'heartbeat', {}), 25000);
        if (tipsTokenTimer) clearInterval(tipsTokenTimer);
        tipsTokenTimer = setInterval(async () => {
          const fresh = await getValidToken();
          if (fresh && tipsWS === ws) sendRealtime(topic, 'access_token', { access_token: fresh });
        }, TIPS_TOKEN_MS);
      };

      ws.onmessage = (ev) => {
        try {
          const msg = JSON.parse(ev.data);
          if (msg.event === 'phx_reply' && msg.ref === joinRef) {
            if (msg.payload?.status === 'ok') {
              tipsTentativas = 0;
              setTipsStatus(null); // pronto, aguardando dicas
              setAlert('dicas', null);
            } else {
              setTipsStatus(null);
              setAlert('dicas', { ...RECONNECTING, kind: 'warn', title: 'Dicas ao vivo indisponíveis', detail: msg.payload?.response?.reason || '' });
              console.error('phx_join failed', msg);
            }
            return;
          }
          if (msg.event === 'phx_error' || msg.event === 'phx_close') {
            // Canal derrubado pelo servidor (por exemplo, login vencido):
            // fecha a conexão e o onclose reconecta.
            console.error(msg.event, msg);
            try { ws.close(); } catch {}
            return;
          }
          const tip = extractRealtimeTip(msg);
          if (tip) addTip(tip);
        } catch (e) {
          console.warn('Sales Coach Realtime parse fail:', e);
        }
      };

      ws.onerror = (event) => {
        // O onclose vem logo depois e cuida da reconexão.
        console.error('Sales Coach tips Realtime WS error:', event);
      };
      ws.onclose = (event) => {
        if (tipsWS !== ws) return;
        if (tipsHeartbeatInterval) clearInterval(tipsHeartbeatInterval);
        if (tipsTokenTimer) clearInterval(tipsTokenTimer);
        tipsHeartbeatInterval = null;
        tipsTokenTimer = null;
        if (liveStopping) return;
        console.warn('Sales Coach: canal das dicas caiu; reconectando', event.code, event.reason);
        setAlert('dicas', RECONNECTING);
        const delay = Math.min(30000, 1000 * 2 ** tipsTentativas);
        tipsTentativas += 1;
        setTimeout(async () => {
          if (liveStopping || tipsWS !== ws) return;
          const fresh = await getValidToken();
          startTipsRealtime(fresh || token, mid);
        }, delay);
      };
    } catch (e) {
      console.warn('Realtime fail:', e);
      setAlert('dicas', { ...RECONNECTING, kind: 'warn', title: 'Dicas ao vivo indisponíveis' });
    }
  }

  function setLiveText(t) { liveTextEl.textContent = t; }
  function setTipsStatus(t) {
    if (tipsEl.querySelector('.sc-hero')) return;
    tipsEl.innerHTML = `<div class="sc-empty">${escape(t || 'As dicas aparecem aqui conforme a conversa avança.')}</div>`;
  }


  function extractRealtimeTip(msg) {
    if (!msg || msg.event !== 'postgres_changes') return null;
    const data = msg.payload?.data || msg.payload;
    return data?.new || data?.record || null;
  }

  function stopLive() {
    liveStopping = true;
    if (coachTimer) { clearTimeout(coachTimer); coachTimer = null; }
    coachPendente = null;
    const channels = Object.keys(liveChannels);
    for (const ch of Object.values(liveChannels)) {
      try { ch.ws && ch.ws.readyState === 1 && ch.ws.send(JSON.stringify({ type: 'Terminate' })); } catch {}
      try { ch.ws && ch.ws.close(); } catch {}
      try { ch.processor && ch.processor.disconnect(); } catch {}
      try { ch.source && ch.source.disconnect(); } catch {}
      try { ch.ctx && ch.ctx.close(); } catch {}
    }
    liveChannels = {};
    const ws = tipsWS;
    tipsWS = null;
    try { ws && ws.close(); } catch {}
    try { tipsHeartbeatInterval && clearInterval(tipsHeartbeatInterval); } catch {}
    try { tipsTokenTimer && clearInterval(tipsTokenTimer); } catch {}
    tipsHeartbeatInterval = null;
    tipsTokenTimer = null;
    // Registra os minutos de transcrição ao vivo (consumo da empresa).
    if (meetingId && channels.length && liveStartedAt) {
      const seconds = Math.round((Date.now() - liveStartedAt) / 1000);
      authed('/functions/v1/live-session', {
        method: 'POST', body: JSON.stringify({ action: 'finish', meetingId, seconds, channels }),
      }).catch(() => {});
      liveStartedAt = 0;
    }
  }

  // Dicas: uma em destaque, com setas para voltar e avançar. A dica nova não
  // troca a que está na tela (o vendedor pode estar no meio da pergunta): ela
  // fica na fila, com o aviso "dica nova", e entra quando o vendedor avança ou
  // quando ele já fez a pergunta da dica atual. Só a urgente de outro assunto
  // (objeção, pergunta direta do cliente) entra na hora, e dá para voltar.
  const tips = [];
  let tipIdx = -1;
  const MAX_DICAS = 40;
  function addTip(tip) {
    tips.push({ ...tip, at: Date.now() });
    if (tips.length > MAX_DICAS) { tips.shift(); tipIdx = Math.max(0, tipIdx - 1); }
    const atual = tips[tipIdx];
    const furaFila = tip.urgencia === 'alta' && (!atual || tip.categoria !== atual.categoria);
    const naUltima = tipIdx >= tips.length - 2;
    if (tipIdx < 0 || (furaFila && naUltima) || (atual && atual.feita && naUltima)) verDica(tips.length - 1);
    else renderNav();
    if (overlay.classList.contains('minimized')) { unseenTips += 1; updatePill(); }
  }
  function verDica(i) {
    if (!tips.length) return;
    tipIdx = Math.max(0, Math.min(tips.length - 1, i));
    const tip = tips[tipIdx];
    tip.vistaEm = tip.vistaEm || Date.now();
    const urg = tip.urgencia === 'alta' ? 'alta' : '';
    const main = tip.acao || tip.titulo || '';
    tipsEl.innerHTML = `
      <div class="sc-hero ${urg}${tip.feita ? ' feita' : ''}">
        <div class="sc-hero-top">
          <span class="sc-chip">${escape(String(tip.categoria || 'dica').replace(/_/g, ' '))}</span>
          ${tip.feita ? '<span class="sc-feita">✓ feita</span>' : ''}
          <span class="sc-age" id="sc-tip-age">${idade(tip.at)}</span>
        </div>
        ${tip.acao ? `<span class="sc-say">${VARIANTE ? `Diga em ${escape(VARIANTE.nomeIdioma)}` : 'Fale agora'}</span>` : ''}
        <p class="sc-hero-text">${escape(main)}</p>
        ${tip.acao && tip.titulo ? `<div class="sc-why">${escape(tip.titulo)}</div>` : ''}
      </div>`;
    renderNav();
  }
  function renderNav() {
    navEl.hidden = tips.length < 2;
    navPos.textContent = `${tipIdx + 1} de ${tips.length}`;
    prevBtn.disabled = tipIdx <= 0;
    nextBtn.disabled = tipIdx >= tips.length - 1;
    const novas = tips.length - 1 - tipIdx;
    novaBtn.hidden = novas < 1;
    novaBtn.textContent = novas === 1 ? 'Dica nova →' : `${novas} dicas novas →`;
  }
  function idade(at) {
    const min = Math.floor((Date.now() - at) / 60000);
    return min < 1 ? 'agora' : `há ${min} min`;
  }

  // ── Roteiro de perguntas ──
  // O tipo de reunião pode ter um roteiro (Configurações → Tipos de reunião).
  // A lista inteira fica visível; a próxima pergunta em destaque. O vendedor
  // marca e desmarca com um clique, e as que ele fizer são marcadas sozinhas
  // pela transcrição da voz dele.
  const roteiro = { tipos: [], key: null, perguntas: [], feitas: [], auto: [] };
  async function carregarRoteiro() {
    try {
      const { meetingData } = await chrome.storage.local.get(['meetingData']);
      const r = await authed('/rest/v1/meeting_types?select=key,label,roteiro&is_active=eq.true&order=sort_order', {}, 10000);
      if (!r.ok) return; // sem a coluna (versão antiga do banco): segue sem roteiro
      const tipos = (await r.json()).filter((t) => t.roteiro && t.roteiro.trim());
      if (!tipos.length) return;
      roteiro.tipos = tipos;
      rotTrocar.innerHTML = tipos.map((t) => `<option value="${escape(t.key)}">${escape(t.label)}</option>`).join('');
      const tipo = meetingData?.meetingType;
      usarRoteiro(tipos.some((t) => t.key === tipo) ? tipo : tipos[0].key, !tipos.some((t) => t.key === tipo));
    } catch (e) {
      console.warn('Sales Coach: roteiro não carregou', e);
    }
  }
  function usarRoteiro(key, recolhido = false) {
    const t = roteiro.tipos.find((x) => x.key === key);
    if (!t) return;
    roteiro.key = key;
    roteiro.perguntas = t.roteiro.split('\n').map((l) => l.trim()).filter(Boolean);
    roteiro.feitas = roteiro.perguntas.map(() => 0);
    roteiro.auto = roteiro.perguntas.map(() => false);
    rotTrocar.value = key;
    rotTitle.textContent = `Roteiro · ${t.label}`;
    rotEl.hidden = false;
    if (recolhido && !rotList.hidden) rotToggle.click();
    rotTrocarWrap.hidden = rotList.hidden || roteiro.tipos.length < 2;
    renderRoteiro();
  }
  function renderRoteiro() {
    const n = roteiro.perguntas.length;
    const feitas = roteiro.feitas.filter(Boolean).length;
    const prox = roteiro.feitas.findIndex((f) => !f);
    rotCount.textContent = `${feitas}/${n}`;
    rotBar.style.width = `${n ? (feitas / n) * 100 : 0}%`;
    rotList.innerHTML = roteiro.perguntas.map((q, i) => `
      <li data-i="${i}" class="${roteiro.feitas[i] ? 'feita' : ''}${i === prox ? ' prox' : ''}" title="${roteiro.feitas[i] ? 'Desmarcar' : 'Marcar como feita'}">
        <span class="sc-rot-check" aria-hidden="true">${roteiro.feitas[i] ? '✓' : ''}</span>
        <span class="sc-rot-n">${i + 1}.</span>
        <span class="sc-rot-q">${escape(q)}</span>
      </li>`).join('');
    // A próxima pergunta fica à vista, sem precisar rolar a lista.
    const el = rotList.querySelector('li.prox');
    if (el && !rotList.hidden) rotList.scrollTop = Math.max(0, el.offsetTop - rotList.offsetTop - 40);
  }

  // Semelhança entre a fala do vendedor e uma pergunta: quanto das palavras
  // que importam na pergunta aparece no que ele acabou de dizer.
  const PARADAS = new Set('a o as os um uma uns umas de da do das dos em na no nas nos por para pra pro com sem que qual quais quanto quantos quantas como e ou se voce voces vc vcs eu nos ele ela eles elas isso esse essa este esta hoje ja tem ter sao sua seu suas seus meu minha mais muito bem aqui la ai entao tipo ne'.split(' '));
  const palavras = (t) => String(t).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9 ]/g, ' ').split(/\s+/).filter((w) => w.length > 2 && !PARADAS.has(w));
  function parecida(pergunta, fala) {
    const q = [...new Set(palavras(pergunta))];
    if (!q.length) return false;
    const f = new Set(palavras(fala).map((w) => w.slice(0, 5)));
    const hits = q.filter((w) => f.has(w.slice(0, 5))).length;
    return q.length <= 2 ? hits === q.length : hits >= 2 && hits / q.length >= 0.6;
  }
  const falasVendedor = [];
  function falaDoVendedor(text) {
    falasVendedor.push(text);
    if (falasVendedor.length > 3) falasVendedor.shift();
    const janela = falasVendedor.join(' ');
    let mudou = false;
    roteiro.perguntas.forEach((q, i) => {
      if (!roteiro.feitas[i] && parecida(q, janela)) { roteiro.feitas[i] = 1; roteiro.auto[i] = true; mudou = true; }
    });
    if (mudou) renderRoteiro();
    // Dica da tela: se o vendedor já fez a pergunta dela, a próxima dica pode entrar.
    const atual = tips[tipIdx];
    if (atual && !atual.feita && atual.acao && parecida(atual.acao, janela)) {
      atual.feita = true;
      if (tipIdx < tips.length - 1) setTimeout(() => { if (tips[tipIdx] === atual) verDica(tipIdx + 1); }, 2500);
      else verDica(tipIdx);
    }
  }
  function updateTipAge() {
    const el = document.getElementById('sc-tip-age');
    if (!el || !tips[tipIdx]) return;
    el.textContent = idade(tips[tipIdx].at);
  }

  // ── Medidores de áudio ──
  // Um analisador por trilha, lido a cada 100 ms. Se o áudio do cliente fica
  // mudo por muito tempo, avisa: costuma ser a aba compartilhada sem áudio.
  const CLIENT_SILENCE_MS = 90000;
  const SEM_CHAMADA_MS = 45000;
  // Microfone que nunca captou som desde o início: provavelmente não é o da chamada.
  const MIC_MUDO_MS = 30000;
  const OUVIR_PELA_ABA = { label: 'Ouvir o cliente pela aba', onClick: () => ouvirPelaAba() };

  /**
   * A voz do cliente não está chegando pela chamada: pede o áudio da aba no
   * meio da gravação (o clique no botão libera o seletor do Chrome) e junta ao
   * cliente. O vídeo que o Chrome obriga a pedir é descartado na hora.
   */
  async function ouvirPelaAba() {
    if (!clienteMix || !mediaRecorder || mediaRecorder.state !== 'recording') return;
    const s = await pedirTela(false);
    if (!s) return;
    for (const t of s.getVideoTracks()) { t.stop(); s.removeTrack(t); }
    if (!s.getAudioTracks().length) {
      setAlert('cliente-mudo', {
        kind: 'warn', title: 'O áudio da aba não veio',
        text: 'Compartilhe de novo e deixe "Compartilhar áudio da guia" ligado.',
        action: OUVIR_PELA_ABA,
      });
      return;
    }
    if (screenStream) for (const t of s.getAudioTracks()) screenStream.addTrack(t);
    else screenStream = s;
    clienteMix.adicionarAba(new MediaStream(s.getAudioTracks()));
    setAlert('sem-cliente', null);
    setAlert('cliente-mudo', null);
    console.info('Sales Coach: áudio da aba adicionado no meio da gravação');
  }
  let meterCtx = null;
  let meterTimer = null;
  function startMeters(mic, tab) {
    stopMeters();
    try {
      meterCtx = new AudioContext();
      meterCtx.resume().catch(() => {});
      const analysers = {};
      for (const [who, stream] of Object.entries({ vendedor: mic, cliente: tab })) {
        if (!stream || !stream.getAudioTracks().length) continue;
        const a = meterCtx.createAnalyser();
        a.fftSize = 1024;
        meterCtx.createMediaStreamSource(stream).connect(a);
        analysers[who] = { a, buf: new Float32Array(a.fftSize) };
      }
      let lastClientSound = Date.now();
      const micDesde = Date.now();
      let micJaOuviu = false;
      meterTimer = setInterval(() => {
        for (const who of ['vendedor', 'cliente']) {
          const m = analysers[who];
          let level = 0;
          if (m) {
            m.a.getFloatTimeDomainData(m.buf);
            let sum = 0;
            for (let i = 0; i < m.buf.length; i++) sum += m.buf[i] * m.buf[i];
            const rms = Math.sqrt(sum / m.buf.length);
            level = Math.min(1, Math.sqrt(rms) * 2);
            if (who === 'cliente' && rms > 0.01) lastClientSound = Date.now();
            if (who === 'vendedor' && rms > 0.01 && !micJaOuviu) {
              micJaOuviu = true;
              if (alerts.has('mic-mudo')) setAlert('mic-mudo', null);
            }
          }
          meterEls[who].style.transform = `scaleX(${level.toFixed(2)})`;
        }
        if (analysers.vendedor && !micJaOuviu && Date.now() - micDesde > MIC_MUDO_MS && !alerts.has('mic-mudo')) {
          setAlert('mic-mudo', {
            kind: 'warn', title: 'Não estou ouvindo o seu microfone',
            text: 'Talvez a extensão esteja num microfone diferente do Meet. Clique abaixo para usar o mesmo microfone da chamada; a gravação continua.',
            action: { label: 'Usar o microfone do Meet', onClick: () => trocarMicrofone(microfoneDaChamada()) },
          });
        }
        if (analysers.cliente) {
          const st = clienteMix?.estado?.() || { trilhas: 0, temAba: false };
          const gravando = Date.now() - startTime;
          // Gravando há um tempo e nenhuma trilha da chamada chegou: a
          // extensão não está ouvindo a chamada. Sem esperar o minuto e meio.
          const semChamada = !st.temAba && st.trilhas === 0 && gravando > SEM_CHAMADA_MS;
          const quiet = semChamada || Date.now() - lastClientSound > CLIENT_SILENCE_MS;
          const key = alerts.get('cliente-mudo')?.semChamada;
          if (quiet !== alerts.has('cliente-mudo') || (quiet && key !== semChamada)) {
            setAlert('cliente-mudo', !quiet ? null : semChamada ? {
              kind: 'warn', semChamada: true, title: 'Ainda não recebi o áudio da chamada',
              text: 'Se o cliente já entrou, clique abaixo e compartilhe esta aba com "Compartilhar áudio da guia". A gravação continua.',
              action: OUVIR_PELA_ABA,
            } : {
              kind: 'warn', semChamada: false, title: 'Não ouço o cliente há mais de 1 minuto',
              text: st.temAba
                ? 'Confira se o cliente está com o microfone ligado.'
                : 'Se ele está falando, clique abaixo e compartilhe esta aba com "Compartilhar áudio da guia". A gravação continua.',
              ...(st.temAba ? {} : { action: OUVIR_PELA_ABA }),
            });
          }
        }
      }, 100);
    } catch (e) {
      console.warn('Sales Coach: medidor de áudio indisponível', e);
    }
  }
  function stopMeters() {
    if (meterTimer) { clearInterval(meterTimer); meterTimer = null; }
    if (meterCtx) { meterCtx.close().catch(() => {}); meterCtx = null; }
  }
  function escape(s) { return String(s).replace(/[&<>"]/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c])); }

  // ── Upload ──
  async function uploadRecording(blob) {
    safeStorageSet({ recordingState: 'uploading' });
    uploading = true;
    try {
      const data = await chrome.storage.local.get(['meetingData']);
      const meta = data.meetingData || {};
      const token = await getValidToken();
      if (!token) { showStatus('error', '❌ Sessão expirada.'); notifyBackground('uploadError', { error: 'Sessão expirada' }); autoRemove(6000); return; }

      const campos = {
        title: meta.title || 'Gravação via Extensão',
        ...(meta.meetingType ? { meeting_type: meta.meetingType } : {}),
        lead_name: meta.leadName || '',
        lead_company: meta.leadCompany || '',
        lead_email: meta.leadEmail || '',
        ...(meetingId ? { meeting_id: meetingId } : {}),
        meeting_url: meta.meetingUrl || location.href,
        ...(meta.calendarEventId ? { calendar_event_id: meta.calendarEventId } : {}),
        ...(meta.attendees?.length ? { attendees: JSON.stringify(meta.attendees) } : {}),
        tela: blob.type.startsWith('video/') ? '1' : '0',
      };

      // 1) Direto no Storage, em partes (vídeo longo não cabe na memória da
      //    função: era o "status 546"); 2) se falhar, o envio antigo, inteiro.
      let result = {};
      let path = null;
      try {
        path = await uploadDireto(blob);
      } catch (err) {
        console.warn('Sales Coach: envio direto falhou, tentando o envio inteiro:', err?.message || err);
      }
      if (path) {
        const res = await fetchWithTimeout(`${SUPABASE_URL}/functions/v1/upload-recording`, {
          method: 'POST',
          headers: { Authorization: `Bearer ${await getValidToken() || token}`, apikey: SUPABASE_ANON_KEY, 'Content-Type': 'application/json' },
          body: JSON.stringify({ ...campos, path }),
        }, 2 * 60 * 1000);
        try { result = await res.json(); } catch {}
        // Servidor ainda sem o registro por caminho: cai no envio inteiro.
        if (!res.ok) { console.warn('Sales Coach: registro falhou:', result.error || res.status); path = null; }
      }
      if (!path) {
        const formData = new FormData();
        formData.append('file', blob, `recording-${Date.now()}.webm`);
        for (const [k, v] of Object.entries(campos)) formData.append(k, v);
        // Prazo generoso: uma reunião longa pode ter centenas de MB.
        const res = await fetchWithTimeout(`${SUPABASE_URL}/functions/v1/upload-recording`, {
          method: 'POST',
          headers: { Authorization: `Bearer ${token}`, apikey: SUPABASE_ANON_KEY },
          body: formData,
        }, 15 * 60 * 1000);
        try { result = await res.json(); } catch {}
        if (!res.ok) throw new Error(result.error || `Erro no envio (status ${res.status})`);
      }

      safeStorageSet({ recordingState: 'done', lastMeetingId: result.meetingId });
      try { chrome.storage.local.remove(['meetingData']); } catch {}
      uploading = false;
      showStatus('success', 'Gravação enviada! Análise em curso.');
      notifyBackground('uploadComplete', { meetingId: result.meetingId });
      autoRemove(5000);
    } catch (err) {
      const msg = err?.message === 'Failed to fetch'
        ? 'Sem conexão com o Sales Coach.'
        : (err?.message || String(err));
      // O vídeo não subiu: o áudio já está quase todo no servidor.
      showStatus('sending', 'O vídeo não subiu. Enviando o áudio da reunião…');
      const rescued = await rescueFromBackup();
      uploading = false;
      notifyBackground(rescued ? 'uploadComplete' : 'uploadError', { error: msg, meetingId });
      failWithDownload([blob], blob.type, rescued
        ? `O vídeo não subiu (${msg}), mas o áudio foi enviado para análise. Se quiser guardar o vídeo, baixe abaixo.`
        : msg, rescued);
    }
  }

  /**
   * Sobe a gravação direto no Storage pelo protocolo retomável (TUS), em
   * partes de 6 MB, com o login do vendedor. Devolve o caminho do arquivo.
   */
  async function uploadDireto(blob) {
    const PARTE = 6 * 1024 * 1024;
    const token = await getValidToken();
    if (!token) throw new Error('sessão expirada');
    let userId = (await chrome.storage.local.get(['userId'])).userId;
    if (!userId) {
      try { userId = JSON.parse(atob(token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/'))).sub; } catch {}
    }
    if (!userId) throw new Error('usuário desconhecido');
    const path = `${userId}/${Date.now()}-recording.webm`;
    const b64 = (t) => btoa(unescape(encodeURIComponent(t)));
    const base = `${SUPABASE_URL}/storage/v1/upload/resumable`;
    const auth = async () => ({ Authorization: `Bearer ${await getValidToken() || token}`, apikey: SUPABASE_ANON_KEY, 'Tus-Resumable': '1.0.0' });

    const criar = await fetchWithTimeout(base, {
      method: 'POST',
      headers: {
        ...(await auth()),
        'Upload-Length': String(blob.size),
        'Upload-Metadata': [
          `bucketName ${b64('meeting-files')}`, `objectName ${b64(path)}`,
          `contentType ${b64((blob.type || 'video/webm').split(';')[0])}`, `cacheControl ${b64('3600')}`,
        ].join(','),
        'x-upsert': 'false',
      },
    }, 60 * 1000);
    const loc = criar.headers.get('Location');
    if (criar.status !== 201 || !loc) throw new Error(`não abriu o envio (status ${criar.status})`);
    const url = new URL(loc, base).toString();

    let offset = 0;
    let falhas = 0;
    while (offset < blob.size) {
      showStatus('sending', `Enviando gravação… ${Math.floor((offset / blob.size) * 100)}%`);
      try {
        const r = await fetchWithTimeout(url, {
          method: 'PATCH',
          headers: { ...(await auth()), 'Upload-Offset': String(offset), 'Content-Type': 'application/offset+octet-stream' },
          body: blob.slice(offset, offset + PARTE),
        }, 3 * 60 * 1000);
        if (r.status !== 204) throw new Error(`parte recusada (status ${r.status})`);
        offset = Number(r.headers.get('Upload-Offset') ?? offset + PARTE);
        falhas = 0;
      } catch (err) {
        if (++falhas > 4) throw err;
        await new Promise((ok) => setTimeout(ok, 2000 * falhas));
        // Retoma de onde o servidor parou.
        const h = await fetchWithTimeout(url, { method: 'HEAD', headers: await auth() }, 30 * 1000).catch(() => null);
        const srv = Number(h?.headers.get('Upload-Offset'));
        if (Number.isFinite(srv) && srv >= 0 && h?.ok) offset = srv;
      }
    }
    return path;
  }

  // ── Helpers ──
  function showStatus(type, text) {
    setMinimized(false);
    initEl.hidden = true;
    recordingEl.hidden = true;
    recEl.hidden = true;
    stopBtn.hidden = true;
    statusMsgEl.hidden = false;
    statusMsgEl.className = `sc-status ${type}`;
    statusMsgEl.textContent = text;
  }
  function notifyBackground(action, extra = {}) {
    // Com a extensão recarregada, sendMessage lança na hora (não rejeita a
    // promessa): o .catch sozinho não segurava e o envio parava no meio.
    try { chrome.runtime.sendMessage({ action, ...extra }).catch(() => {}); } catch {}
  }
  function safeStorageSet(obj) {
    try { chrome.storage.local.set(obj).catch?.(() => {}); } catch {}
  }

  /**
   * O envio falhou: mostra o motivo e oferece o arquivo, para a reunião não se
   * perder. O vendedor pode subir o arquivo depois em Agendas.
   */
  function failWithDownload(parts, type, message, rescued = false) {
    const blob = new Blob(parts, { type: type || 'video/webm' });
    showStatus(rescued ? 'success' : 'error', rescued ? message : `❌ ${message}`);
    if (blob.size < 100) { autoRemove(8000); return; }
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `reuniao-${new Date().toISOString().slice(0, 16).replace(/[:T]/g, '-')}.webm`;
    a.className = 'sc-btn sc-btn-primary';
    a.textContent = 'Baixar a gravação';
    const hint = document.createElement('div');
    hint.className = 'sc-hint';
    hint.textContent = rescued ? 'O vídeo é opcional: a análise usa o áudio.' : 'Depois, envie o arquivo em Agendas → Nova Agenda.';
    const close = document.createElement('button');
    close.type = 'button';
    close.className = 'sc-btn';
    close.textContent = 'Fechar';
    close.addEventListener('click', () => { URL.revokeObjectURL(url); autoRemove(0); });
    statusMsgEl.after(a, hint, close);
    safeStorageSet({ recordingState: 'idle' });
  }
  function encerrarInstancia() {
    try { chrome.runtime.onMessage.removeListener(onMessage); } catch {}
    try { vigiaMic.disconnect(); } catch {}
    if (window.__salescoachStartRecording === startRecording) window.__salescoachStartRecording = undefined;
    if (window.__salescoachStopRecording === stopRecording) window.__salescoachStopRecording = undefined;
  }
  function autoRemove(delay) {
    setTimeout(() => {
      encerrarInstancia();
      overlay.remove();
      safeStorageSet({ recordingState: 'idle' });
      try { chrome.storage.local.remove(['recordingStartTime', 'recordingMode', 'isScreenSharing']); } catch {}
    }, delay);
  }
  function startTimer() {
    stopTimer();
    timerInterval = setInterval(() => {
      const e = Math.floor((Date.now() - startTime) / 1000);
      const h = Math.floor(e / 3600);
      const m = String(Math.floor((e % 3600) / 60)).padStart(2, '0');
      const s = String(e % 60).padStart(2, '0');
      const text = h ? `${h}:${m}:${s}` : `${m}:${s}`;
      timerEl.textContent = text;
      pillTime.textContent = text;
      if (e % 30 === 0) updateTipAge();
    }, 1000);
  }
  function stopTimer() { if (timerInterval) { clearInterval(timerInterval); timerInterval = null; } }
})();
